YAAAAAAAAY! Thank you for extracting me! 

---

## Task Description

1. Create two users: `alice` and `bob`
2. Create a group named `project_group`
3. Add both users to the project group
4. Compress the `files` directory into a file named `files.zip`
5. Change the owner of `files.zip` to `alice`
6. Change the group of `files.zip` to `project_group`
7. Set the following permissions for `files.zip`:
    - Owner can read and write
    - Group can read only
    - Others have no access

--- 
Good luck!